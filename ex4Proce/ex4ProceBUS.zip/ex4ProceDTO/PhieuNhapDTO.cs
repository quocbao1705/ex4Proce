﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex4ProceDTO
{
    public class PhieuNhapDTO
    {
        public string MaPN { get; set; }
        public string MaNCC { get; set; }
        public DateTime NgayNhap { get; set; }
    }
}
